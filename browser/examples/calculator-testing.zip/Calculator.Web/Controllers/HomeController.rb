class HomeController < Controller
  def index
    view nil, 'layout'
  end
end
