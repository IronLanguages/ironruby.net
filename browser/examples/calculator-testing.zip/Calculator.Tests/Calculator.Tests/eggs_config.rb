Eggs.config(
  :tests => [
    :calculator, 
    :python_engine,
    :function
  ]
)
